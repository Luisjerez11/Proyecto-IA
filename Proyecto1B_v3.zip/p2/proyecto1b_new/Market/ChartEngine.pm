package Market::ChartEngine;
use strict;
use warnings;
use Tk;
use lib '.';
use POSIX qw(floor ceil);
use Market::Panels::PricePanel;
use Market::Panels::ATRPanel;

sub new {
    my ($class, %args) = @_;
    my $self = {
        market => $args{market}, indicators => $args{indicators},
        mw => $args{mw}, canvas => undef,
        tf => 1, visible => 160, first => 0,
        left => 4, scale_w => 92, bottom_h => 30,
        atr_h => 170, vol_h => 82, auto_y => 1,
        lock_y_on_zoom => 0,
        price_min => 0, price_max => 1,
        locked_index => undef, mouse_index => undef,
        atr_min => undef,
        atr_max => undef,
        drag => undef, resize_atr => 0,
        debug_scroll => 1, wheel_count => 0,
        price_panel => Market::Panels::PricePanel->new(),
        atr_panel => Market::Panels::ATRPanel->new(),
    };
    bless $self, $class;
    return $self;
}

sub run {
    my ($self) = @_;
    my $mw = $self->{mw};
    $mw->title('Motor de Charting - TradingView simple');
    $mw->geometry('1400x800');
    eval { $mw->attributes('-fullscreen', 0); };

    my $top = $mw->Frame(-background => '#1e222d', -relief => 'flat')->pack(-side => 'top', -fill => 'x');

    # Colores del toolbar — solo visual, sin lógica
    my %TF_ACTIVE   = (-foreground => '#ffffff', -background => '#2962ff',
                       -activeforeground => '#ffffff', -activebackground => '#1a47cc');
    my %TF_INACTIVE = (-foreground => '#b2b5be', -background => '#1e222d',
                       -activeforeground => '#ffffff', -activebackground => '#2a2e39');

    # ── Menú desplegable de Temporalidades ──
    my %TF_LABELS = (1=>'1m', 5=>'5m', 15=>'15m', 60=>'1H', 120=>'2H', 240=>'4H', 1440=>'1D', 10080=>'1W');
    my @TF_ORDER  = (1, 5, 15, 60, 120, 240, 1440, 10080);

    my $tf_label_var = $TF_LABELS{ $self->{tf} };
    my $tf_mb = $top->Menubutton(
        -text             => "TF: $tf_label_var",
        -relief           => 'flat',
        -borderwidth      => 0,
        -padx             => 12,
        -pady             => 5,
        -font             => ['Arial', 9, 'bold'],
        -foreground       => '#ffffff',
        -background       => '#2962ff',
        -activeforeground => '#ffffff',
        -activebackground => '#1a47cc',
        -cursor           => 'hand2',
        -indicatoron      => 0,
    );
    $self->{tf_mb} = $tf_mb;

    my $tf_menu = $tf_mb->Menu(-tearoff => 0, -background => '#1e222d',
        -foreground => '#b2b5be', -activebackground => '#2962ff',
        -activeforeground => '#ffffff', -font => ['Arial', 9, 'bold'],
        -relief => 'flat', -bd => 1);

    for my $tf (@TF_ORDER) {
        my $lbl = $TF_LABELS{$tf};
        $tf_menu->add('command',
            -label   => $lbl,
            -command => sub {
                $self->set_timeframe($tf);
                $self->{tf_mb}->configure(-text => "TF: $lbl");
            },
        );
    }
    $tf_mb->configure(-menu => $tf_menu);
    $tf_mb->pack(-side => 'left', -padx => 4);

    # Separador visual entre botones de TF y botón de escala
    $top->Label(
        -text       => '|',
        -foreground => '#363a45',
        -background => '#1e222d',
        -font       => ['Arial', 11],
        -padx       => 4,
    )->pack(-side => 'left');

    my $scale_btn = $top->Button(
        -text             => '⬍ Escala Auto',
        -relief           => 'flat',
        -borderwidth      => 0,
        -padx             => 10,
        -pady             => 5,
        -font             => ['Arial', 9, 'bold'],
        -foreground       => '#ffffff',
        -background       => '#089981',
        -activeforeground => '#ffffff',
        -activebackground => '#067a68',
        -cursor           => 'hand2',
    );
    $scale_btn->configure(-command => sub {
        $self->{auto_y} = $self->{auto_y} ? 0 : 1;  # lógica intacta
        $self->{lock_y_on_zoom} = 0;                  # lógica intacta
        if ($self->{auto_y}) {
            $scale_btn->configure(
                -text             => '⬍ Escala Auto',
                -background       => '#089981',
                -activebackground => '#067a68',
            );
        } else {
            $scale_btn->configure(
                -text             => '⬌ Escala Fija',
                -background       => '#c0392b',
                -activebackground => '#a93226',
            );
        }
        $self->draw;  # lógica intacta
    });
    $scale_btn->pack(-side => 'left', -padx => 6);

    # Separador visual
    $top->Label(
        -text => '|', -foreground => '#363a45', -background => '#1e222d',
        -font => ['Arial', 11], -padx => 4,
    )->pack(-side => 'left');

    # --- Botón REPLAY ---
    $self->{replay_active} = 0;
    $self->{replay_index}  = undef;
    $self->{replay_after}  = undef;
    my $replay_btn = $top->Button(
        -text => '▶ Replay', -relief => 'flat', -borderwidth => 0,
        -padx => 10, -pady => 5, -font => ['Arial', 9, 'bold'],
        -foreground => '#b2b5be', -background => '#1e222d',
        -activeforeground => '#ffffff', -activebackground => '#2a2e39',
        -cursor => 'hand2',
    );
    $self->{replay_btn} = $replay_btn;
    $replay_btn->configure(-command => sub { $self->toggle_replay(); });
    $replay_btn->pack(-side => 'left', -padx => 4);

    # --- Botón ESTRUCTURA ---
    $self->{show_structure} = 0;
    my $struct_btn = $top->Button(
        -text => '◈ Estructura', -relief => 'flat', -borderwidth => 0,
        -padx => 10, -pady => 5, -font => ['Arial', 9, 'bold'],
        -foreground => '#b2b5be', -background => '#1e222d',
        -activeforeground => '#ffffff', -activebackground => '#2a2e39',
        -cursor => 'hand2',
    );
    $self->{struct_btn} = $struct_btn;
    $struct_btn->configure(-command => sub {
        $self->{show_structure} = $self->{show_structure} ? 0 : 1;
        if ($self->{show_structure}) {
            $struct_btn->configure(-foreground => '#f5c518', -background => '#2a2614');
        } else {
            $struct_btn->configure(-foreground => '#b2b5be', -background => '#1e222d');
        }
        $self->draw();
    });
    $struct_btn->pack(-side => 'left', -padx => 2);

    # --- Botón SWIT (Swing High/Low labels HH HL LH LL) ---
    $self->{show_swit} = 0;
    my $swit_btn = $top->Button(
        -text => '⬡ SWIT', -relief => 'flat', -borderwidth => 0,
        -padx => 10, -pady => 5, -font => ['Arial', 9, 'bold'],
        -foreground => '#b2b5be', -background => '#1e222d',
        -activeforeground => '#ffffff', -activebackground => '#2a2e39',
        -cursor => 'hand2',
    );
    $self->{swit_btn} = $swit_btn;
    $swit_btn->configure(-command => sub {
        $self->{show_swit} = $self->{show_swit} ? 0 : 1;
        if ($self->{show_swit}) {
            $swit_btn->configure(-foreground => '#00bcd4', -background => '#0a1f24');
        } else {
            $swit_btn->configure(-foreground => '#b2b5be', -background => '#1e222d');
        }
        $self->draw();
    });
    $swit_btn->pack(-side => 'left', -padx => 2);

    # --- Botón LIQUIDEZ ---
    $self->{show_liquidity} = 0;
    my $liq_btn = $top->Button(
        -text => '◎ Liquidez', -relief => 'flat', -borderwidth => 0,
        -padx => 10, -pady => 5, -font => ['Arial', 9, 'bold'],
        -foreground => '#b2b5be', -background => '#1e222d',
        -activeforeground => '#ffffff', -activebackground => '#2a2e39',
        -cursor => 'hand2',
    );
    $self->{liq_btn} = $liq_btn;
    $liq_btn->configure(-command => sub {
        $self->{show_liquidity} = $self->{show_liquidity} ? 0 : 1;
        if ($self->{show_liquidity}) {
            $liq_btn->configure(-foreground => '#ff9800', -background => '#231a05');
        } else {
            $liq_btn->configure(-foreground => '#b2b5be', -background => '#1e222d');
        }
        $self->draw();
    });
    $liq_btn->pack(-side => 'left', -padx => 2);


    my $canvas = $mw->Canvas(-background => '#131722', -highlightthickness => 0)->pack(-fill => 'both', -expand => 1);

    $canvas->configure(-cursor => 'crosshair');

    $self->{canvas} = $canvas;

    $canvas->bindtags([$canvas]);

    my $configured_once = 0;

    $canvas->Tk::bind('<Configure>' => sub {
        if (!$configured_once) {
            $configured_once = 1;
            $self->fit_all();
        }
        $self->draw();
    });
    $canvas->Tk::bind('<Motion>' => [sub {my ($w, $x, $y, $s) = @_;
        $self->mouse_move($x, $y, $s);
    },
        Tk::Ev('x'), Tk::Ev('y'), Tk::Ev('s')
    ]);

    $canvas->Tk::bind('<ButtonPress-1>' => [
        sub {
            my ($w, $x, $y) = @_;
            $self->mouse_down($x, $y);
        },
        Tk::Ev('x'), Tk::Ev('y')
    ]);

    $canvas->Tk::bind('<B1-Motion>' => [
        sub {
            my ($w, $x, $y) = @_;
            $self->mouse_drag($x, $y);
        },
        Tk::Ev('x'), Tk::Ev('y')
    ]);

    $canvas->Tk::bind('<ButtonRelease-1>' => [
        sub {
            my ($w, $x, $y) = @_;
            $self->mouse_up($x, $y);
        },
        Tk::Ev('x'), Tk::Ev('y')
    ]);
    $canvas->Tk::bind('<Button-4>' => [
    sub {
        my ($w, $x, $y, $s) = @_;
        $self->mouse_wheel(120, $x, $y, $s);
        return "break";
    },
    Tk::Ev('x'), Tk::Ev('y'), Tk::Ev('s')
]);

$canvas->Tk::bind('<Button-5>' => [
    sub {
        my ($w, $x, $y, $s) = @_;
        $self->mouse_wheel(-120, $x, $y, $s);
        return "break";
    },
    Tk::Ev('x'), Tk::Ev('y'), Tk::Ev('s')
]);
$canvas->Tk::bind('<MouseWheel>' => [
    sub {
        my ($w, $delta, $x, $y, $s) = @_;
        $self->mouse_wheel($delta, $x, $y, $s);
        return "break";
    },
    Tk::Ev('D'), Tk::Ev('x'), Tk::Ev('y'), Tk::Ev('s')
]);



    #$mw->Tk::bind('<Button-4>'       => sub { $self->mouse_wheel(120); return 'break'; });
    #$mw->Tk::bind('<Button-5>'       => sub { $self->mouse_wheel(-120); return 'break'; });
    #$mw->Tk::bind('<MouseWheel>'     => sub { $self->mouse_wheel(Tk::Ev('D')); return 'break'; });

    # Teclas de prueba: + separa velas, - junta velas.
    # Sirven para saber si falla la rueda o si falla la logica del zoom.
    $mw->Tk::bind('<plus>'  => sub { $self->mouse_wheel(120); });
    $mw->Tk::bind('<minus>' => sub { $self->mouse_wheel(-120); });
    $mw->Tk::bind('<Escape>' => sub { $mw->destroy; });

    $self->fit_all();
    $self->draw();
    MainLoop;
}

sub set_timeframe {
    my ($self, $tf) = @_;
    # Detener replay si estaba activo
    if ($self->{replay_active}) {
        $self->{replay_active} = 0;
        $self->{mw}->after_cancel($self->{replay_after}) if $self->{replay_after};
        $self->{replay_end}   = undef;
        $self->{replay_index} = undef;
        $self->{replay_btn}->configure(-text => '▶ Replay', -foreground => '#b2b5be', -background => '#1e222d')
            if $self->{replay_btn};
    }
    $self->{tf} = $tf;
    $self->{market}->set_timeframe($tf);
    $self->{indicators}->reset_all();
    $self->{indicators}->update_last($self->{market});
    $self->{locked_index} = undef;
    $self->{lock_y_on_zoom} = 0;
    $self->fit_all();
    $self->draw();
}

sub fit_all {
    my ($self) = @_;
    my $n = $self->{market}->size();
    return if $n <= 0;

    $self->{visible} = 180;
    $self->{visible} = $n + 4 if $n < 180;

    $self->{first} = $n - $self->{visible} + 2;
    $self->limit_first();
}

sub layout {
    my ($self) = @_;
    my $c = $self->{canvas};
    my $w = $c->width  || 1200;
    my $h = $c->height || 700;
    my $right = $w - $self->{scale_w};
    # Los paneles siempre quedan fijos: precio arriba y ATR abajo.
    # El zoom horizontal no debe cambiar estas posiciones.
    $self->{atr_h} = 80  if $self->{atr_h} < 80;
    $self->{atr_h} = 320 if $self->{atr_h} > 320;
    my $atr_top = $h - $self->{bottom_h} - $self->{atr_h};
    $atr_top = 120 if $atr_top < 120;
    my $price_h = $atr_top;
    my $plot_w = $right - $self->{left};
    
    my $step = $plot_w / $self->{visible};  
    my $bar_w = $step * 0.65;

    $bar_w = 1 if $bar_w < 1;
    $bar_w = 120 if $bar_w > 120;


    return ($w, $h, $right, $atr_top, $price_h, $plot_w, $bar_w);
}


sub request_draw {
    my ($self) = @_;
    return if $self->{_render_pending};
    $self->{_render_pending} = 1;
    my $mw = $self->{mw};
    $mw->after(16, sub {
        $self->{_render_pending} = 0;
        $self->draw();
    });
}

sub _draw_crosshair_only {
    my ($self) = @_;
    my $ctx = $self->{_last_render_ctx};
    return $self->draw() if !$ctx;
    my $c = $self->{canvas};
    return if !$c;
    $c->delete('crosshair');
    $self->draw_crosshair(
        $ctx->{start}, $ctx->{end}, $ctx->{x_of}, $ctx->{right}, $ctx->{h}, $ctx->{state}
    ) if defined $self->{mouse_x};
}

sub draw {
    my ($self) = @_;
    my $c = $self->{canvas};
    return if !$c;
    $c->delete('all');

    my ($w, $h, $right, $atr_top, $price_h, $plot_w, $bar_w) = $self->layout();

    # --- Fondos de ejes (capa base, se dibuja primero) ---
    # Franja derecha: eje Y
    $c->createRectangle(
        $right, 0, $w, $h,
        -fill => '#0f1117', -outline => '#0f1117'
    );
    $c->createLine($right, 0, $right, $h, -fill => '#2a2e39', -width => 1);

    # Franja inferior: eje X
    $c->createRectangle(
        0, $h - $self->{bottom_h}, $w, $h,
        -fill => '#0f1117', -outline => '#0f1117'
    );
    $c->createLine(0, $h - $self->{bottom_h}, $w, $h - $self->{bottom_h},
        -fill => '#2a2e39', -width => 1);
    # --- Fin fondos de ejes ---

    

    my $last = $self->{market}->last_index();
    my $start = floor($self->{first});
    my $end = ceil($self->{first} + $self->{visible} - 1);
    
    


    $start = 0 if $start < 0;
    $end = $last if $end > $last;

    my $data = $self->{market}->get_slice($start, $end);
    my $atr = $self->{indicators}->slice_array('ATR', $start, $end);



    

    my $step = $plot_w / $self->{visible};

    my $x_of = sub {
        my ($local_i) = @_;
        my $global_i = $start + $local_i;

        return $self->{left}
            + ($step / 2)
            + ($global_i - $self->{first}) * $step;
    };

    my %state = (
        w => $w, h => $h, left => $self->{left}, right => $right, scale_w => $self->{scale_w},
        top => 0, price_h => $price_h, atr_top => $atr_top, atr_h => $self->{atr_h},
        vol_h => $self->{vol_h}, bar_w => $bar_w, auto_y => $self->{auto_y},
        lock_y => $self->{lock_y_on_zoom},
        price_min => $self->{price_min}, price_max => $self->{price_max}, tf => $self->{tf},
        atr_min => $self->{atr_min},
        atr_max => $self->{atr_max},
        start_index => $start,
        end_index   => $end,
        mouse_index => $self->{mouse_index},
        last_candle => $self->{market}->last_candle(),
    );

    $self->draw_time_axis($start, $end, $x_of, $right, $h);
    $self->{price_panel}->draw($c, $data, $x_of, \%state);
    $self->{price_min} = $state{price_min};
    $self->{price_max} = $state{price_max};

    # Limpia el área del ATR para ocultar cualquier vela/volumen que se haya pasado.
    $c->createRectangle(
        $self->{left}, $atr_top,
        $right, $h - $self->{bottom_h},
        -fill => '#131722',
        -outline => '#131722'
    );

$c->createLine($self->{left}, $atr_top, $right, $atr_top, -fill => '#2a2e39', -width => 1);

$self->{atr_panel}->draw($c, $atr, $x_of, \%state);


    $self->{atr_min} = $state{atr_min};
    $self->{atr_max} = $state{atr_max};

    # Contexto de render usado para redibujar solo el crosshair al mover el mouse.
    # Así se evita repintar miles de velas solo por mover el cursor.
    $self->{_last_render_ctx} = {
        start => $start, end => $end, x_of => $x_of, right => $right, h => $h, state => { %state },
    };

    # --- Replay: limitar velas visibles al índice de replay ---
    if ($self->{replay_active} || defined $self->{replay_end}) {
        # el draw ya usó get_slice($start, $end); si replay_end < end
        # simplemente la vista ya está limitada por fit/first.
    }

    # --- Estructura de mercado (BOS/CHoCH) y etiquetas SWIT ---
    if ($self->{show_structure} || $self->{show_swit}) {
        $self->draw_structure($c, $x_of, \%state, $start, $end);
    }

    # --- Zonas de liquidez ---
    if ($self->{show_liquidity}) {
        $self->draw_liquidity($c, $x_of, \%state, $start, $end);
    }

    $self->draw_crosshair($start, $end, $x_of, $right, $h, \%state) if defined $self->{mouse_x};
}

sub draw_time_axis {
    my ($self, $start, $end, $x_of, $right, $h) = @_;
    my $c = $self->{canvas};
    my $data = $self->{market}->get_slice($start, $end);
    return if !@$data;

    # Optimización: las etiquetas de tiempo son costosas en Tk. Se dibujan
    # pocos pivots importantes y una cantidad limitada de horas, aunque haya
    # miles de velas visibles.
    my @day_positions;
    my $last_day_x = -9999;
    my $min_day_gap = 48;
    my %seen_day;

    # Pivots de cambio de día. Se revisa toda la ventana, pero solo se dibuja
    # cuando hay suficiente separación visual.
    for my $i (0 .. $#$data) {
        my $time = $data->[$i]{time};
        my ($date) = $time =~ /(\d{4}-\d{2}-\d{2})/;
        next if !defined $date;
        my $prev = $i > 0 ? $data->[$i-1]{time} : '';
        my ($prev_date) = $prev =~ /(\d{4}-\d{2}-\d{2})/;
        my $new_day = defined($prev_date) && $date ne $prev_date;
        next if !$new_day;

        my $x = $x_of->($i);
        next if $x < $self->{left} || $x > $right;
        push @day_positions, $x;
        $c->createLine($x, 0, $x, $h - $self->{bottom_h}, -fill => '#363a45', -tags => 'grid');
        next if $x - $last_day_x < $min_day_gap;
        $last_day_x = $x;
        my $x_label = $x;
        $x_label = $self->{left} + 28 if $x_label < $self->{left} + 28;
        $x_label = $right - 28       if $x_label > $right - 28;
        $c->createText($x_label, $h - 14,
            -text => _day_label($date, $self->{tf}), -fill => '#d1d4dc',
            -font => ['Arial', 9, 'bold'], -tags => 'time');
    }

    # Horas con salto adaptativo: en TF diario/semanal no hay hora relevante
    return if $self->{tf} >= 1440;
    my $visible = scalar(@$data);
    my $stride = int($visible / 12);
    $stride = 1 if $stride < 1;
    my $last_label_x = -9999;

    for (my $i = 0; $i <= $#$data; $i += $stride) {
        my $time = $data->[$i]{time};
        my ($date, $hh, $mm) = $time =~ /(\d{4}-\d{2}-\d{2})T(\d{2}):(\d{2})/;
        next if !defined $date;
        my $x = $x_of->($i);
        next if $x < $self->{left} || $x > $right;

        my $near_day = 0;
        for my $day_x (@day_positions) {
            if (abs($x - $day_x) < 55) { $near_day = 1; last; }
        }
        next if $near_day;
        next if $x - $last_label_x < 55;
        $last_label_x = $x;

        $c->createLine($x, 0, $x, $h - $self->{bottom_h}, -fill => '#2a2e39', -tags => 'grid');
        $c->createText($x, $h - 14,
            -text => "$hh:$mm", -fill => '#787b86',
            -font => ['Arial', 9, 'normal'], -tags => 'time');
    }
}

sub _day_label {
    my ($date, $tf) = @_;
    my ($y, $m, $d) = split /-/, $date;
    $tf //= 1;
    # En TF diario o semanal mostrar mes+año cuando cambia el mes
    if ($tf >= 1440) {
        my @MONTHS = qw(Ene Feb Mar Abr May Jun Jul Ago Sep Oct Nov Dic);
        return $MONTHS[$m-1] . " '" . substr($y,2,2);
    }
    return "$d/$m";
}

sub draw_crosshair {
    my ($self, $start, $end, $x_of, $right, $h, $state) = @_;

    my $c = $self->{canvas};

    return if !defined $self->{mouse_x};
    return if !defined $self->{mouse_y};

    my $x = $self->{mouse_x};
    my $y = $self->{mouse_y};

    return if $x < $self->{left};
    return if $x > $right;

    my $idx = $self->x_to_index($x);
    $idx = $start if $idx < $start;
    $idx = $end   if $idx > $end;

    my $local_i = $idx - $start;
    my $candle = $self->{market}->get_candle($idx);

    # Snap horizontal: la línea vertical se pega al centro de la vela.
    if ($candle) {
        $x = $x_of->($local_i);
    }
# Snap vertical a O/H/L/C solo si el mouse está cerca de esos precios.
if ($candle && $y < $state->{atr_top}) {

    my @levels = (
        $candle->{open},
        $candle->{high},
        $candle->{low},
        $candle->{close},
    );

    my $best_y;
    my $best_dist = 999999;

    for my $price (@levels) {
        my $level_y = $self->{price_panel}->{scale}->price_to_y(
            $price,
            $self->{price_min},
            $self->{price_max},
            0,
            $state->{price_h}
        );

        my $dist = abs($y - $level_y);

        if ($dist < $best_dist) {
            $best_dist = $dist;
            $best_y = $level_y;
        }
    }

    # Sensibilidad del snap: 8 px.
    # Sube a 12 si quieres que se pegue más fácil.
    if ($best_dist <= 8) {
        $y = $best_y;
    }
}



    # Línea vertical y horizontal del crosshair
    $c->createLine($x, 0, $x, $h - $self->{bottom_h},
        -fill => '#9598a1', -dash => [4,4], -tags => 'crosshair');

    $c->createLine($self->{left}, $y, $right, $y,
        -fill => '#9598a1', -dash => [4,4], -tags => 'crosshair');




    my $label;

    if ($y < $state->{atr_top}) {
        my $price = $self->{price_panel}->{scale}->y_to_price(
    $y,
    $self->{price_min},
    $self->{price_max},
    0,
    $state->{price_h}
);

$price = _round_to_tick($price, 0.25);
$label = sprintf("%.2f", $price);
    } else {
        $label = sprintf("%.2f", $self->{atr_panel}->{scale}->y_to_price(
            $y,
            $self->{atr_min},
            $self->{atr_max},
            $state->{atr_top},
            $state->{atr_h}
        ));
    }

    $c->createRectangle($right + 2, $y - 10, $right + $self->{scale_w} - 5, $y + 10,
        -fill => '#c62828', -outline => '#c62828', -tags => 'crosshair');

    $c->createText($right + 8, $y,
        -anchor => 'w',
        -text => $label,
        -fill => 'white', -tags => 'crosshair');

    

    if ($candle && $y < $h - $self->{bottom_h}) {
        my ($date, $hhmm) = $candle->{time} =~ /(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2})/;

        my $label_x = $x;

        # Mantener la etiqueta negra dentro del área visible.
        my $label_half_w = 55;
        my $min_x = $self->{left} + $label_half_w;
        my $max_x = $right - $label_half_w;

        $label_x = $min_x if $label_x < $min_x;
        $label_x = $max_x if $label_x > $max_x;

        $c->createRectangle($label_x - $label_half_w, $h - 34,
                            $label_x + $label_half_w, $h - 12,
            -fill => '#363a45', -outline => '#363a45', -tags => 'crosshair');

        $c->createText($label_x, $h - 23,
            -text => "$date  $hhmm",
            -fill => '#d1d4dc',
            -font => ['Arial', 9], -tags => 'crosshair');
    }


    # Mostrar OHLC de la vela actual del crosshair
if ($candle) {
    my $ohlc = sprintf(
        "O %.2f   H %.2f   L %.2f   C %.2f",
        $candle->{open},
        $candle->{high},
        $candle->{low},
        $candle->{close}
    );

    my $color = ($candle->{close} >= $candle->{open}) ? '#089981' : '#f23645';

    $c->createText(
        $self->{left} + 8,
        16,
        -anchor => 'w',
        -text => $ohlc,
        -fill => $color,
        -font => ['Arial', 10, 'bold'],
        -tags => 'crosshair'
    );
}
}

sub mouse_move {
    my ($self, $x, $y, $state) = @_;

    $self->{mouse_x} = $x;
    $self->{mouse_y} = $y;
    $self->{ctrl_down} = ($state & 0x0004) ? 1 : 0;

    my $idx = $self->x_to_index($x);
    my $last = $self->{market}->last_index();

    $idx = 0 if $idx < 0;
    $idx = $last if $idx > $last;

    $self->{mouse_index} = $idx;

    $self->_draw_crosshair_only();
    return;
}

sub x_to_index {
    my ($self, $x) = @_;
    my ($w, $h, $right, $atr_top, $price_h, $plot_w) = $self->layout();

    my $step = $plot_w / $self->{visible};

    my $idx = int(
        $self->{first}
        + (($x - $self->{left} - ($step / 2)) / $step)
        + 0.5
    );

    $idx = 0 if $idx < 0;
    $idx = $self->{market}->last_index if $idx > $self->{market}->last_index;

    return $idx;
}

sub mouse_down {
    my ($self, $x, $y) = @_;
    my ($w, $h, $right, $atr_top) = $self->layout();

    # Drag sobre escala inferior: zoom horizontal
    if ($y >= $h - $self->{bottom_h}) {
        my ($w, $h, $right, $atr_top, $price_h, $plot_w) = $self->layout();

        my $ratio = ($x - $self->{left}) / $plot_w;
        $ratio = 0 if $ratio < 0;
        $ratio = 1 if $ratio > 1;

        $self->{time_scale_drag} = {
            x => $x,
            visible => $self->{visible},
            first => $self->{first},
            ratio => $ratio,
            anchor => $self->{first} + $ratio * $self->{visible},
        };

        return;
    }

    # Click sobre eje Y derecho: activar escalado vertical manual
    if ($x >= $right) {
        my $panel = ($y >= $atr_top) ? 'atr' : 'price';

        $self->{scale_drag} = {
            y => $y,
            panel => $panel,
            price_min => $self->{price_min},
            price_max => $self->{price_max},
            atr_min   => $self->{atr_min},
            atr_max   => $self->{atr_max},
        };

        return;
    }

    if (abs($y - $atr_top) < 6) {
        $self->{resize_atr} = 1;
    } else {
        my $panel = ($y >= $atr_top) ? 'atr' : 'price';

        $self->{drag} = {
            x => $x,
            y => $y,
            first => $self->{first},
            panel => $panel,

            price_min => $self->{price_min},
            price_max => $self->{price_max},

            atr_min => $self->{atr_min},
            atr_max => $self->{atr_max},
        };
    }
}

sub mouse_drag {
    my ($self, $x, $y) = @_;
    my ($w, $h, $right, $atr_top, $price_h, $plot_w) = $self->layout();


    if ($self->{time_scale_drag}) {
        my $dx = $x - $self->{time_scale_drag}{x};

        # Izquierda: alejar / más velas
        # Derecha: acercar / menos velas
        my $factor = exp(-$dx / 250);
        my $new_visible = int($self->{time_scale_drag}{visible} * $factor);

        my $n = $self->{market}->last_index() + 1;
        $new_visible = 2  if $new_visible < 2;
        $new_visible = $n if $new_visible > $n;

        my $ratio  = $self->{time_scale_drag}{ratio};
        my $anchor = $self->{time_scale_drag}{anchor};

        $self->{visible} = $new_visible;
        $self->{first} = $anchor - $ratio * $new_visible;

        $self->limit_first();

        if ($self->{auto_y}) {
            $self->{lock_y_on_zoom} = 0;
            delete $self->{price_min};
            delete $self->{price_max};
            delete $self->{atr_min};
            delete $self->{atr_max};
        }

        $self->request_draw();
        return;
    }

    if ($self->{scale_drag}) {
    my $dy = $y - $self->{scale_drag}{y};

    # Arriba: estirar velas/ATR
    # Abajo: comprimir velas/ATR
    my $factor = 1 + abs($dy) / 180;
    $factor = 1 / $factor if $dy < 0;

    # Si Auto vertical está activo:
    # solo permitimos arrastre horizontal.
    # El eje Y se recalcula automáticamente con las velas visibles.
    if ($self->{auto_y}) {
        $self->{lock_y_on_zoom} = 0;
        $self->request_draw();
        return;
    }

    # Si Auto vertical está apagado:
    # permitimos movimiento vertical manual.
    $self->{lock_y_on_zoom} = 1;

    if ($self->{scale_drag}{panel} eq 'price') {
        my $min = $self->{scale_drag}{price_min};
        my $max = $self->{scale_drag}{price_max};
        my $mid = ($min + $max) / 2;
        my $range = ($max - $min) * $factor;

        $self->{price_min} = $mid - $range / 2;
        $self->{price_max} = $mid + $range / 2;
    } else {
        my $min = $self->{scale_drag}{atr_min};
        my $max = $self->{scale_drag}{atr_max};
        my $mid = ($min + $max) / 2;
        my $range = ($max - $min) * $factor;

        $self->{atr_min} = $mid - $range / 2;
        $self->{atr_max} = $mid + $range / 2;
    }

    $self->request_draw();
    return;
}


    if ($self->{resize_atr}) {
        my $new = $h - $self->{bottom_h} - $y;
        $new = 80 if $new < 80;
        $new = 320 if $new > 320;
        $self->{atr_h} = $new;
    }
    elsif ($self->{drag}) {
        my $dx = $x - $self->{drag}{x};
        my $dy = $y - $self->{drag}{y};

        # Movimiento horizontal: tiempo/eje X
        $self->{first} = $self->{drag}{first} - $dx / $plot_w * $self->{visible};
        $self->limit_first();

            if ($self->{auto_y}) {
        # Auto vertical activo:
        # NO tocar Y manualmente.
        # NO bloquear Y.
        # El draw recalcula la escala con lo visible.
        $self->{lock_y_on_zoom} = 0;

        delete $self->{price_min};
        delete $self->{price_max};
        delete $self->{atr_min};
        delete $self->{atr_max};

        $self->request_draw();
        return;
    }
        $self->{lock_y_on_zoom} = 1;

        if ($self->{drag}{panel} eq 'price') {
            my $range = $self->{drag}{price_max} - $self->{drag}{price_min};
            $range = 1 if $range == 0;

            my $shift = $dy / $price_h * $range;

            $self->{price_min} = $self->{drag}{price_min} + $shift;
            $self->{price_max} = $self->{drag}{price_max} + $shift;
        }
        elsif ($self->{drag}{panel} eq 'atr') {
            my $range = $self->{drag}{atr_max} - $self->{drag}{atr_min};
            $range = 1 if !defined($range) || $range == 0;

            my $shift = $dy / $self->{atr_h} * $range;

            $self->{atr_min} = $self->{drag}{atr_min} + $shift;
            $self->{atr_max} = $self->{drag}{atr_max} + $shift;
        }
    }

    $self->request_draw();
}

sub mouse_up {
    my ($self, $x, $y) = @_;

    delete $self->{drag};
    delete $self->{resize_atr};
    delete $self->{scale_drag};
    delete $self->{time_scale_drag};

    $self->request_draw();
}

sub mouse_wheel {
    my ($self, $delta, $mouse_x, $mouse_y, $state) = @_;

    my $n = $self->{market}->last_index() + 1;
    return if $n <= 0;

    my ($w, $h, $right, $atr_top, $price_h, $plot_w, $bar_w) = $self->layout();

    my $old_visible = $self->{visible};
    my $old_first   = $self->{first};
    my $old_right   = $old_first + $old_visible;

    my $ctrl = defined($state) && ($state & 0x0004);

    my $new_visible;

    if ($delta > 0) {
        $new_visible = int($old_visible * 0.80);   # acercar
        $new_visible = $old_visible - 1 if $new_visible == $old_visible;
    } else {
        $new_visible = int($old_visible * 1.25);   # alejar
        $new_visible = $old_visible + 1 if $new_visible == $old_visible;
    }

    # Límites absolutos de zoom
    $new_visible = 2  if $new_visible < 2;
    $new_visible = $n if $new_visible > $n;

    if ($ctrl && defined($mouse_x) && $mouse_x >= $self->{left} && $mouse_x <= $right) {

        my $current_index = $self->x_to_index($mouse_x);
        $current_index = 0      if $current_index < 0;
        $current_index = $n - 1 if $current_index > $n - 1;

        # Se actualiza el ancla si es primera vez o si cambiaste de vela.
        if (
            !$self->{ctrl_zoom_anchor}
            || $self->{ctrl_zoom_anchor}{mouse_index} != $current_index
        ) {
            $self->{ctrl_zoom_anchor} = {
                index       => $current_index,
                mouse_index => $current_index,
                mouse_x     => $mouse_x,
            };
        }

        my $anchor_index = $self->{ctrl_zoom_anchor}{index};
        my $anchor_x     = $self->{ctrl_zoom_anchor}{mouse_x};

        my $new_step = $plot_w / $new_visible;

        # Fórmula compatible con x_of:
        # x = left + step/2 + (index - first) * step
        # Despejando first:
        $self->{first} = $anchor_index
            - (($anchor_x - $self->{left} - ($new_step / 2)) / $new_step);

    } else {

        # Si ya no hay Ctrl, se libera el congelado.
        delete $self->{ctrl_zoom_anchor};

        # Scroll normal mantiene fijo el borde derecho.
        $self->{first} = $old_right - $new_visible;
    }

    $self->{visible} = $new_visible;

    # IMPORTANTE:
    # En Ctrl + scroll NO llamamos limit_first porque mueve la vela ancla.
    # En scroll normal sí.
    if (!$ctrl) {
        $self->limit_first();
    }

    eval { $self->{canvas}->yviewMoveto(0); };

    if ($self->{auto_y}) {
        $self->{lock_y_on_zoom} = 0;
        delete $self->{price_min};
        delete $self->{price_max};
        delete $self->{atr_min};
        delete $self->{atr_max};
    } else {
        $self->{lock_y_on_zoom} = 1;
    }

    $self->request_draw();
}


sub limit_first {
    my ($self) = @_;

    my $n = $self->{market}->last_index() + 1;
    return if $n <= 0;

    # Extremo izquierdo:
    # permite espacio blanco a la izquierda y deja las 2 primeras velas
    # pegadas al lado derecho, junto a la escala.
    my $min_first = 2 - $self->{visible};

    # Extremo derecho:
    # permite que las 2 últimas velas queden al lado izquierdo
    # y luego haya espacio blanco hacia la derecha.
    my $max_first = $n - 2;

    $max_first = 0 if $max_first < 0;

    $self->{first} = $min_first if $self->{first} < $min_first;
    $self->{first} = $max_first if $self->{first} > $max_first;
}

sub go_to_start {
    my ($self) = @_;

    # Inicio: las 2 primeras velas quedan junto a la escala derecha.
    $self->{first} = 2 - $self->{visible};
    $self->limit_first();

    if ($self->{auto_y}) {
        delete $self->{price_min};
        delete $self->{price_max};
        delete $self->{atr_min};
        delete $self->{atr_max};
        $self->{lock_y_on_zoom} = 0;
    }

    $self->draw();
}

sub go_to_end {
    my ($self) = @_;

    my $n = $self->{market}->last_index() + 1;

    # Queremos que en el borde izquierdo queden solo 2 velas visibles
    # y luego espacio blanco hasta la última vela en el lado derecho.
    $self->{first} = $n - 2;

    if ($self->{auto_y}) {
        delete $self->{price_min};
        delete $self->{price_max};
        delete $self->{atr_min};
        delete $self->{atr_max};
        $self->{lock_y_on_zoom} = 0;
    }

    $self->draw();
}

sub _round_to_tick {
    my ($value, $tick) = @_;
    $tick = 0.25 if !defined $tick || $tick <= 0;
    return int($value / $tick + ($value >= 0 ? 0.5 : -0.5)) * $tick;
}



# ─────────────────────────────────────────────────────────────────────────────
# REPLAY
# ─────────────────────────────────────────────────────────────────────────────
sub toggle_replay {
    my ($self) = @_;
    if ($self->{replay_active}) {
        $self->{replay_active} = 0;
        $self->{mw}->after_cancel($self->{replay_after}) if $self->{replay_after};
        $self->{replay_btn}->configure(
            -text => '▶ Replay', -foreground => '#b2b5be', -background => '#1e222d');
    } else {
        if (!defined $self->{replay_index} || $self->{replay_index} >= $self->{market}->size() - 1) {
            $self->{replay_index} = 14;
        }
        $self->{replay_active} = 1;
        $self->{replay_btn}->configure(
            -text => '⏸ Pause', -foreground => '#ffffff', -background => '#2962ff');
        $self->_replay_step();
    }
}

sub _replay_step {
    my ($self) = @_;
    return if !$self->{replay_active};
    my $total = $self->{market}->size();
    if ($self->{replay_index} >= $total - 1) {
        $self->{replay_active} = 0;
        $self->{replay_btn}->configure(
            -text => '▶ Replay', -foreground => '#b2b5be', -background => '#1e222d');
        return;
    }
    $self->{replay_index}++;
    my $idx = $self->{replay_index};
    $self->{replay_end} = $idx;
    my $new_first = $idx - $self->{visible} + 4;
    $self->{first} = $new_first;
    $self->limit_first();
    if ($self->{auto_y}) {
        delete $self->{price_min}; delete $self->{price_max};
        delete $self->{atr_min};   delete $self->{atr_max};
    }
    $self->draw();
    $self->{replay_after} = $self->{mw}->after(80, sub { $self->_replay_step(); });
}

# ─────────────────────────────────────────────────────────────────────────────
# ANÁLISIS DE SWINGS  (indices GLOBALES sobre el dataset completo)
# ─────────────────────────────────────────────────────────────────────────────

# Devuelve aref de { index=>GLOBAL, price, type=>'H'|'L', label }
# sobre TODOS los datos del timeframe activo.
sub _get_all_swings {
    my ($self, $n) = @_;
    $n //= 3;

    # Cache: recalcular solo si cambió el timeframe o el tamaño del dataset
    my $size = $self->{market}->size();
    my $tf   = $self->{tf};
    if (   defined $self->{_swing_cache_tf}
        && $self->{_swing_cache_tf}   == $tf
        && $self->{_swing_cache_size} == $size
        && $self->{_swing_cache_n}    == $n) {
        return $self->{_swing_cache};
    }

    # Obtener dataset completo
    my $all = $self->{market}->get_slice(0, $self->{market}->last_index());
    my $last = $#$all;
    my @swings;

    for my $i ($n .. $last - $n) {
        my $h = $all->[$i]{high};
        my $l = $all->[$i]{low};
        my ($is_sh, $is_sl) = (1, 1);
        for my $j ($i - $n .. $i + $n) {
            next if $j == $i;
            $is_sh = 0 if $all->[$j]{high} >= $h;
            $is_sl = 0 if $all->[$j]{low}  <= $l;
        }
        if ($is_sh) { push @swings, { index => $i, price => $h, type => 'H' }; }
        if ($is_sl) { push @swings, { index => $i, price => $l, type => 'L' }; }
    }

    @swings = sort { $a->{index} <=> $b->{index} } @swings;

    # Etiquetar HH / HL / LH / LL
    my ($last_h, $last_l);
    for my $s (@swings) {
        if ($s->{type} eq 'H') {
            if    (!defined $last_h)        { $s->{label} = 'SH'; }
            elsif ($s->{price} > $last_h)   { $s->{label} = 'HH'; }
            else                             { $s->{label} = 'LH'; }
            $last_h = $s->{price};
        } else {
            if    (!defined $last_l)        { $s->{label} = 'SL'; }
            elsif ($s->{price} < $last_l)   { $s->{label} = 'LL'; }
            else                             { $s->{label} = 'HL'; }
            $last_l = $s->{price};
        }
    }

    # Marcar si cada swing fue barrido por alguna vela posterior
    for my $s (@swings) {
        my $swept = 0;
        for my $j ($s->{index} + 1 .. $last) {
            if ($s->{type} eq 'H' && $all->[$j]{high} > $s->{price}) { $swept = 1; last; }
            if ($s->{type} eq 'L' && $all->[$j]{low}  < $s->{price}) { $swept = 1; last; }
        }
        $s->{swept} = $swept;
    }

    # Guardar en cache
    $self->{_swing_cache}      = \@swings;
    $self->{_swing_cache_tf}   = $tf;
    $self->{_swing_cache_size} = $size;
    $self->{_swing_cache_n}    = $n;

    return \@swings;
}

# ─────────────────────────────────────────────────────────────────────────────
# ESTRUCTURA DE MERCADO: BOS / CHoCH
# ─────────────────────────────────────────────────────────────────────────────
sub _get_bos_choch {
    my ($self, $swings) = @_;
    my @events;
    my $trend;
    for my $i (1 .. $#$swings) {
        my $curr  = $swings->[$i];
        my $label = $curr->{label} // '';
        if ($curr->{type} eq 'H') {
            if (defined $trend) {
                if    ($trend eq 'bull' && $label eq 'HH') {
                    push @events, { %$curr, kind => 'BOS',   dir => 'bull' };
                } elsif ($trend eq 'bear' && $label eq 'HH') {
                    push @events, { %$curr, kind => 'CHoCH', dir => 'bull' };
                    $trend = 'bull';
                }
            }
            $trend //= ($label eq 'HH') ? 'bull' : 'bear';
        } else {
            if (defined $trend) {
                if    ($trend eq 'bear' && $label eq 'LL') {
                    push @events, { %$curr, kind => 'BOS',   dir => 'bear' };
                } elsif ($trend eq 'bull' && $label eq 'LL') {
                    push @events, { %$curr, kind => 'CHoCH', dir => 'bear' };
                    $trend = 'bear';
                }
            }
            $trend //= ($label eq 'LL') ? 'bear' : 'bull';
        }
    }
    return \@events;
}

# ─────────────────────────────────────────────────────────────────────────────
# DRAW: SWIT (etiquetas HH/HL/LH/LL) + ESTRUCTURA (BOS/CHoCH)
# ─────────────────────────────────────────────────────────────────────────────
sub draw_structure {
    my ($self, $c, $x_of, $state, $start, $end) = @_;

    my $swings = $self->_get_all_swings(3);

    my $scale = $self->{price_panel}->{scale};
    my $pmin  = $state->{price_min};
    my $pmax  = $state->{price_max};
    my $top   = $state->{top};
    my $ph    = $state->{price_h};
    my $left  = $state->{left};
    my $right = $state->{right};

    # Filtrar solo swings dentro de la ventana visible
    my @visible = grep { $_->{index} >= $start && $_->{index} <= $end } @$swings;

    # ── SWIT: puntos + etiquetas ──
    if ($self->{show_swit}) {
        for my $s (@visible) {
            next if !defined $s->{label};
            # local_i = posición relativa al slice, para x_of
            my $local_i = $s->{index} - $start;
            my $x = $x_of->($local_i);
            next if $x < $left - 2 || $x > $right + 2;

            my $y = $scale->price_to_y($s->{price}, $pmin, $pmax, $top, $ph);
            next if $y < $top || $y > $top + $ph;

            my $is_high = ($s->{type} eq 'H');
            my $color   = $is_high ? '#26c6da' : '#ef5350';
            my $label   = $s->{label};

            # Línea horizontal corta centrada en el swing
            $c->createLine($x - 12, $y, $x + 12, $y,
                -fill => $color, -width => 1.5, -tags => 'structure');
            # Punto
            $c->createOval($x-3, $y-3, $x+3, $y+3,
                -fill => $color, -outline => $color, -tags => 'structure');
            # Etiqueta encima del high, debajo del low
            my $ty = $is_high ? $y - 13 : $y + 13;
            $c->createText($x, $ty, -anchor => 'center',
                -text => $label, -fill => $color,
                -font => ['Arial', 8, 'bold'], -tags => 'structure');
        }
    }

    # ── ESTRUCTURA: BOS / CHoCH ──
    if ($self->{show_structure}) {
        my $events = $self->_get_bos_choch($swings);
        for my $ev (@$events) {
            next if $ev->{index} < $start || $ev->{index} > $end;
            my $local_i = $ev->{index} - $start;
            my $x  = $x_of->($local_i);
            next if $x < $left || $x > $right;

            my $y = $scale->price_to_y($ev->{price}, $pmin, $pmax, $top, $ph);
            next if $y < $top || $y > $top + $ph;

            my $is_bull = ($ev->{dir} eq 'bull');
            my $color   = $is_bull ? '#26a69a' : '#ef5350';
            my $label   = $ev->{kind};   # 'BOS' o 'CHoCH'

            # Línea horizontal desde el punto del evento hasta el borde derecho
            $c->createLine($x, $y, $right, $y,
                -fill => $color, -dash => [6,3], -width => 1.2, -tags => 'structure');
            # Badge con fondo
            my $tw = length($label) * 6 + 8;
            $c->createRectangle($x - $tw/2, $y - 9, $x + $tw/2, $y + 9,
                -fill => $color, -outline => $color, -tags => 'structure');
            $c->createText($x, $y, -anchor => 'center',
                -text => $label, -fill => '#ffffff',
                -font => ['Arial', 8, 'bold'], -tags => 'structure');
        }
    }
}

# ─────────────────────────────────────────────────────────────────────────────
# DRAW: ZONAS DE LIQUIDEZ  (BSL / SSL)
# ─────────────────────────────────────────────────────────────────────────────
sub draw_liquidity {
    my ($self, $c, $x_of, $state, $start, $end) = @_;

    my $swings = $self->_get_all_swings(3);

    my $scale = $self->{price_panel}->{scale};
    my $pmin  = $state->{price_min};
    my $pmax  = $state->{price_max};
    my $top   = $state->{top};
    my $ph    = $state->{price_h};
    my $left  = $state->{left};
    my $right = $state->{right};

    for my $s (@$swings) {
        # Solo pintar si el nivel está dentro del rango Y visible
        my $y = $scale->price_to_y($s->{price}, $pmin, $pmax, $top, $ph);
        next if $y < $top || $y > $top + $ph;

        # Calcular X de inicio: si el swing está fuera del rango visible a la
        # izquierda, la línea arranca desde el borde izquierdo del canvas.
        my $x_start;
        if ($s->{index} >= $start) {
            my $local_i = $s->{index} - $start;
            $x_start = $x_of->($local_i);
            next if $x_start > $right;   # fuera de pantalla a la derecha
            $x_start = $left if $x_start < $left;
        } else {
            # Swing a la izquierda de la ventana: mostrar nivel extendido
            $x_start = $left;
        }

        my $is_high  = ($s->{type} eq 'H');
        my $liq_type = $is_high ? 'BSL' : 'SSL';    # Buy-Side / Sell-Side

        if (!$s->{swept}) {
            # ── Nivel ACTIVO (no barrido): zona naranja ──
            my $zone_h = 4;   # altura de la zona en px
            $c->createRectangle(
                $x_start, $y - $zone_h, $right, $y + $zone_h,
                -fill => '#ff9800', -outline => '',
                -tags => 'liquidity'
            );
            $c->createLine($x_start, $y, $right, $y,
                -fill => '#ffa726', -width => 1.5, -dash => [8,3],
                -tags => 'liquidity');
            # Etiqueta al borde derecho
            my $label_y = $is_high ? $y - 11 : $y + 11;
            $c->createText($right - 3, $label_y, -anchor => 'e',
                -text => $liq_type,
                -fill => '#ffcc80',
                -font => ['Arial', 8, 'bold'],
                -tags => 'liquidity');
        } else {
            # ── Nivel BARRIDO: línea tenue + ✕ en el punto del sweep ──
            # Solo mostrar si el swing estaba visible
            next if $s->{index} < $start || $s->{index} > $end;
            my $local_i = $s->{index} - $start;
            my $xs = $x_of->($local_i);
            next if $xs < $left || $xs > $right;
            my $color = $is_high ? '#80deea' : '#ef9a9a';
            $c->createLine($xs, $y, $right, $y,
                -fill => $color, -width => 0.8, -dash => [4,4],
                -tags => 'liquidity');
            $c->createText($xs, $y, -anchor => 'center',
                -text => 'x',
                -fill => $color,
                -font => ['Arial', 9, 'bold'],
                -tags => 'liquidity');
        }
    }
}

1;
