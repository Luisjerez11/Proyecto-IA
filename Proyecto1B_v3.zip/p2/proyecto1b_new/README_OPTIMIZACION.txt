Proyecto optimizado manteniendo las funcionalidades existentes.

Cambios aplicados:
- Renderiza únicamente la ventana visible de velas.
- Agrupa velas por píxel cuando hay demasiadas velas en pantalla.
- Agrupa puntos ATR cuando hay más puntos que píxeles útiles.
- El crosshair ya no redibuja todo el gráfico; solo actualiza la capa del crosshair.
- Se limita el render durante arrastre/rueda usando after(16), aproximando 60 FPS.
- Se reducen etiquetas de tiempo y escala para evitar saturación de textos en Tk.
- Se conservan CSV, temporalidades, ATR, volumen, crosshair, Auto/Fija, zoom y arrastres existentes.

Ejecución:
perl market.pl 2026_03.csv

──────────────────────────────────────────────
NUEVAS FUNCIONALIDADES (sin tocar el código existente)
──────────────────────────────────────────────
TEMPORALIDADES ADICIONALES
  Se agregaron 1H (60m), 2H (120m), 4H (240m) y 1D (1440m).
  Cambio mínimo en MarketData::build_timeframes (4 líneas extra).
  En ChartEngine se extendió el loop de botones a la lista
  (1, 5, 15, 60, 120, 240, 1440) con etiquetas legibles.

REPLAY (▶ Replay / ⏸ Pause)
  Reproduce el histórico vela a vela a ~12 velas/segundo.
  Implementado en toggle_replay() + _replay_step() usando after(80ms).
  Se detiene automáticamente al llegar al final o al cambiar TF.

ESTRUCTURA DE MERCADO (◈ Estructura)
  Detecta BOS (Break of Structure) y CHoCH (Change of Character)
  a partir de swings de orden 3.
  Dibuja líneas horizontales con etiqueta coloreada (verde=alcista / rojo=bajista).

SWIT + ETIQUETAS HH HL LH LL (⬡ SWIT)
  Detecta Swing Highs y Swing Lows y los clasifica como:
    HH  Higher High   — máximo más alto que el anterior
    HL  Higher Low    — mínimo más alto que el anterior
    LH  Lower High    — máximo más bajo que el anterior
    LL  Lower Low     — mínimo más bajo que el anterior
  Punto circular en el swing + etiqueta encima/debajo.

ZONAS DE LIQUIDEZ (◎ Liquidez)
  Traza niveles BSL (Buy-Side Liquidity) y SSL (Sell-Side Liquidity)
  en los swings que aún no han sido barridos por el precio.
  Los niveles barridos muestran una marca ✕ en el punto de sweep.
  Zona sombreada naranja sobre el nivel activo.

Ejecución:
perl market.pl 2026_03.csv
