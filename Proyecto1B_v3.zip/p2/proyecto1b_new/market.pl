use strict;
use warnings;
use FindBin;
use lib $FindBin::Bin;
use lib "$FindBin::Bin/Market";
use lib ".";
use Tk;
use Market::MarketData;
use Market::IndicatorManager;
use Market::Indicators::ATR;
use Market::ChartEngine;

# ─────────────────────────────────────────────────────────────────────────────
# Carga de datos: acepta uno o varios CSV como argumento, o bien carga
# automáticamente todos los CSV del directorio del script en orden cronológico.
# ─────────────────────────────────────────────────────────────────────────────
my @csv_files;

if (@ARGV) {
    @csv_files = @ARGV;
} else {
    # Buscar todos los .csv en el directorio del script, orden alfabético
    my $dir = $FindBin::Bin;
    opendir my $dh, $dir or die "No se puede abrir directorio '$dir': $!";
    @csv_files = sort
        map  { "$dir/$_" }
        grep { /\.csv$/i }
        readdir $dh;
    closedir $dh;
}

die "No se encontraron archivos CSV.\n" unless @csv_files;

print "Archivos a cargar:\n";
print "  $_\n" for @csv_files;

my $market = Market::MarketData->new();

for my $csv (@csv_files) {
    print "Cargando '$csv'...\n";
    $market->load_csv($csv);
}

# build_timeframes() se llama dentro de load_csv cada vez; la última llamada
# habrá construido todos los TF sobre el dataset completo.  Pero si cargamos
# varios archivos necesitamos reconstruir al final:
$market->build_timeframes() if @csv_files > 1;

$market->set_timeframe(1);
print "Total velas de 1 minuto: ", $market->size(), "\n";

my $indicators = Market::IndicatorManager->new();
$indicators->register('ATR', Market::Indicators::ATR->new(period => 14));
$indicators->update_last($market);

my $mw    = MainWindow->new();
my $chart = Market::ChartEngine->new(
    mw         => $mw,
    market     => $market,
    indicators => $indicators,
);
$chart->run();
