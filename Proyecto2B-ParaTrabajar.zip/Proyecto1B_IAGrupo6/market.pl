use strict;
use warnings;
use FindBin;
use lib $FindBin::Bin;
use lib "$FindBin::Bin/Market";
use lib ".";
use Tk;
use sml;
use Market::MarketData;
use Market::IndicatorManager;
use Market::Indicators::ATR;
use Market::ChartEngine;
use Time::Piece;

my $csv = $ARGV[0] || "$FindBin::Bin/2026_03.csv";
print "Cargando datos desde '$csv'...\n";

my $dataset = sml->load_csv($csv);

my $market = Market::MarketData->new();

for my $row (@$dataset) {
    $row->[0] =~ s/\.\d+//;

   my $time = $row->[0];
$time =~ s/\.\d+//;

my $clean = $time;
$clean =~ s/[-+]\d\d:\d\d$//;

my $epoch = Time::Piece->strptime($clean, '%Y-%m-%dT%H:%M:%S')->epoch;

    $market->add_candle({
        time   => $time,
        epoch  => $epoch,
        open   => $row->[1] + 0,
        high   => $row->[2] + 0,
        low    => $row->[3] + 0,
        close  => $row->[4] + 0,
        volume => $row->[5] + 0,
    });
}

$market->build_timeframes();
$market->set_timeframe(1);


print "Datos cargados: ", $market->size(), " velas de 1 minuto.\n";

my $indicators = Market::IndicatorManager->new();
$indicators->register('ATR', Market::Indicators::ATR->new(period => 14));
$indicators->update_last($market);

my $mw = MainWindow->new();
my $chart = Market::ChartEngine->new(
    mw => $mw,
    market => $market,
    indicators => $indicators,
);
$chart->run();
