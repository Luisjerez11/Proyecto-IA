package Market::ChartEngine;
use strict;
use warnings;
use Tk;
use lib '.';
use POSIX qw(floor ceil);
use Market::Panels::PricePanel;
use Market::Panels::ATRPanel;

sub new {
    my ($class, %args) = @_;
    my $self = {
        market => $args{market}, indicators => $args{indicators},
        mw => $args{mw}, canvas => undef,
        tf => 1, visible => 160, first => 0,
        left => 4, scale_w => 92, bottom_h => 30,
        atr_h => 170, vol_h => 82, auto_y => 1,
        lock_y_on_zoom => 0,
        price_min => 0, price_max => 1,
        locked_index => undef, mouse_index => undef,
        atr_min => undef,
        atr_max => undef,
        drag => undef, resize_atr => 0,
        debug_scroll => 1, wheel_count => 0,
        price_panel => Market::Panels::PricePanel->new(),
        atr_panel => Market::Panels::ATRPanel->new(),
    };
    bless $self, $class;
    return $self;
}

sub run {
    my ($self) = @_;
    my $mw = $self->{mw};
    $mw->title('Motor de Charting - TradingView simple');
    $mw->geometry('1400x800');
    eval { $mw->attributes('-fullscreen', 0); };

    my $top = $mw->Frame(-background => '#1e222d', -relief => 'flat')->pack(-side => 'top', -fill => 'x');

    # Colores del toolbar — solo visual, sin lógica
    my %TF_ACTIVE   = (-foreground => '#ffffff', -background => '#2962ff',
                       -activeforeground => '#ffffff', -activebackground => '#1a47cc');
    my %TF_INACTIVE = (-foreground => '#b2b5be', -background => '#1e222d',
                       -activeforeground => '#ffffff', -activebackground => '#2a2e39');

    # Helper visual: actualiza los 3 botones según cuál TF está activo
    my $_refresh_tf_btns = sub {
        my ($active_tf) = @_;
        for my $tf (1, 5, 15) {
            my $btn = $self->{tf_btns}{$tf};
            next if !$btn;
            if ($tf == $active_tf) {
                $btn->configure(%TF_ACTIVE);
            } else {
                $btn->configure(%TF_INACTIVE);
            }
        }
    };
    $self->{_refresh_tf_btns} = $_refresh_tf_btns;

    for my $tf (1, 5, 15) {
        my $label = "${tf}m";
        my %colors = ($tf == $self->{tf}) ? %TF_ACTIVE : %TF_INACTIVE;
        my $btn = $top->Button(
            -text         => $label,
            -relief       => 'flat',
            -borderwidth  => 0,
            -padx         => 12,
            -pady         => 5,
            -font         => ['Arial', 9, 'bold'],
            -cursor       => 'hand2',
            %colors,
        );
        $btn->configure(-command => sub {
            $self->set_timeframe($tf);          # lógica intacta
            $_refresh_tf_btns->($tf);           # solo visual
        });
        $btn->pack(-side => 'left', -padx => 1);
        $self->{tf_btns}{$tf} = $btn;
    }

    # Separador visual entre botones de TF y botón de escala
    $top->Label(
        -text       => '|',
        -foreground => '#363a45',
        -background => '#1e222d',
        -font       => ['Arial', 11],
        -padx       => 4,
    )->pack(-side => 'left');

    my $scale_btn = $top->Button(
        -text             => '⬍ Escala Auto',
        -relief           => 'flat',
        -borderwidth      => 0,
        -padx             => 10,
        -pady             => 5,
        -font             => ['Arial', 9, 'bold'],
        -foreground       => '#ffffff',
        -background       => '#089981',
        -activeforeground => '#ffffff',
        -activebackground => '#067a68',
        -cursor           => 'hand2',
    );
    $scale_btn->configure(-command => sub {
        $self->{auto_y} = $self->{auto_y} ? 0 : 1;  # lógica intacta
        $self->{lock_y_on_zoom} = 0;                  # lógica intacta
        if ($self->{auto_y}) {
            $scale_btn->configure(
                -text             => '⬍ Escala Auto',
                -background       => '#089981',
                -activebackground => '#067a68',
            );
        } else {
            $scale_btn->configure(
                -text             => '⬌ Escala Fija',
                -background       => '#c0392b',
                -activebackground => '#a93226',
            );
        }
        $self->draw;  # lógica intacta
    });
    $scale_btn->pack(-side => 'left', -padx => 6);


    my $canvas = $mw->Canvas(-background => '#131722', -highlightthickness => 0)->pack(-fill => 'both', -expand => 1);

    $canvas->configure(-cursor => 'crosshair');

    $self->{canvas} = $canvas;

    $canvas->bindtags([$canvas]);

    my $configured_once = 0;

    $canvas->Tk::bind('<Configure>' => sub {
        if (!$configured_once) {
            $configured_once = 1;
            $self->fit_all();
        }
        $self->draw();
    });
    $canvas->Tk::bind('<Motion>' => [sub {my ($w, $x, $y, $s) = @_;
        $self->mouse_move($x, $y, $s);
    },
        Tk::Ev('x'), Tk::Ev('y'), Tk::Ev('s')
    ]);

    $canvas->Tk::bind('<ButtonPress-1>' => [
        sub {
            my ($w, $x, $y) = @_;
            $self->mouse_down($x, $y);
        },
        Tk::Ev('x'), Tk::Ev('y')
    ]);

    $canvas->Tk::bind('<B1-Motion>' => [
        sub {
            my ($w, $x, $y) = @_;
            $self->mouse_drag($x, $y);
        },
        Tk::Ev('x'), Tk::Ev('y')
    ]);

    $canvas->Tk::bind('<ButtonRelease-1>' => [
        sub {
            my ($w, $x, $y) = @_;
            $self->mouse_up($x, $y);
        },
        Tk::Ev('x'), Tk::Ev('y')
    ]);
    $canvas->Tk::bind('<Button-4>' => [
    sub {
        my ($w, $x, $y, $s) = @_;
        $self->mouse_wheel(120, $x, $y, $s);
        return "break";
    },
    Tk::Ev('x'), Tk::Ev('y'), Tk::Ev('s')
]);

$canvas->Tk::bind('<Button-5>' => [
    sub {
        my ($w, $x, $y, $s) = @_;
        $self->mouse_wheel(-120, $x, $y, $s);
        return "break";
    },
    Tk::Ev('x'), Tk::Ev('y'), Tk::Ev('s')
]);
$canvas->Tk::bind('<MouseWheel>' => [
    sub {
        my ($w, $delta, $x, $y, $s) = @_;
        $self->mouse_wheel($delta, $x, $y, $s);
        return "break";
    },
    Tk::Ev('D'), Tk::Ev('x'), Tk::Ev('y'), Tk::Ev('s')
]);



    #$mw->Tk::bind('<Button-4>'       => sub { $self->mouse_wheel(120); return 'break'; });
    #$mw->Tk::bind('<Button-5>'       => sub { $self->mouse_wheel(-120); return 'break'; });
    #$mw->Tk::bind('<MouseWheel>'     => sub { $self->mouse_wheel(Tk::Ev('D')); return 'break'; });

    # Teclas de prueba: + separa velas, - junta velas.
    # Sirven para saber si falla la rueda o si falla la logica del zoom.
    $mw->Tk::bind('<plus>'  => sub { $self->mouse_wheel(120); });
    $mw->Tk::bind('<minus>' => sub { $self->mouse_wheel(-120); });
    $mw->Tk::bind('<Escape>' => sub { $mw->destroy; });

    $self->fit_all();
    $self->draw();
    MainLoop;
}

sub set_timeframe {
    my ($self, $tf) = @_;
    $self->{tf} = $tf;
    $self->{market}->set_timeframe($tf);
    $self->{indicators}->reset_all();
    $self->{indicators}->update_last($self->{market});
    $self->{locked_index} = undef;
    $self->{lock_y_on_zoom} = 0;
    $self->fit_all();
    $self->draw();
}

sub fit_all {
    my ($self) = @_;
    my $n = $self->{market}->size();
    return if $n <= 0;

    $self->{visible} = 180;
    $self->{visible} = $n + 4 if $n < 180;

    $self->{first} = $n - $self->{visible} + 2;
    $self->limit_first();
}

sub layout {
    my ($self) = @_;
    my $c = $self->{canvas};
    my $w = $c->width  || 1200;
    my $h = $c->height || 700;
    my $right = $w - $self->{scale_w};
    # Los paneles siempre quedan fijos: precio arriba y ATR abajo.
    # El zoom horizontal no debe cambiar estas posiciones.
    $self->{atr_h} = 80  if $self->{atr_h} < 80;
    $self->{atr_h} = 320 if $self->{atr_h} > 320;
    my $atr_top = $h - $self->{bottom_h} - $self->{atr_h};
    $atr_top = 120 if $atr_top < 120;
    my $price_h = $atr_top;
    my $plot_w = $right - $self->{left};
    
    my $step = $plot_w / $self->{visible};  
    my $bar_w = $step * 0.65;

    $bar_w = 1 if $bar_w < 1;
    $bar_w = 120 if $bar_w > 120;


    return ($w, $h, $right, $atr_top, $price_h, $plot_w, $bar_w);
}


sub request_draw {
    my ($self) = @_;
    return if $self->{_render_pending};
    $self->{_render_pending} = 1;
    my $mw = $self->{mw};
    $mw->after(16, sub {
        $self->{_render_pending} = 0;
        $self->draw();
    });
}

sub _draw_crosshair_only {
    my ($self) = @_;
    my $ctx = $self->{_last_render_ctx};
    return $self->draw() if !$ctx;
    my $c = $self->{canvas};
    return if !$c;
    $c->delete('crosshair');
    $self->draw_crosshair(
        $ctx->{start}, $ctx->{end}, $ctx->{x_of}, $ctx->{right}, $ctx->{h}, $ctx->{state}
    ) if defined $self->{mouse_x};
}

sub draw {
    my ($self) = @_;
    my $c = $self->{canvas};
    return if !$c;
    $c->delete('all');

    my ($w, $h, $right, $atr_top, $price_h, $plot_w, $bar_w) = $self->layout();

    # --- Fondos de ejes (capa base, se dibuja primero) ---
    # Franja derecha: eje Y
    $c->createRectangle(
        $right, 0, $w, $h,
        -fill => '#0f1117', -outline => '#0f1117'
    );
    $c->createLine($right, 0, $right, $h, -fill => '#2a2e39', -width => 1);

    # Franja inferior: eje X
    $c->createRectangle(
        0, $h - $self->{bottom_h}, $w, $h,
        -fill => '#0f1117', -outline => '#0f1117'
    );
    $c->createLine(0, $h - $self->{bottom_h}, $w, $h - $self->{bottom_h},
        -fill => '#2a2e39', -width => 1);
    # --- Fin fondos de ejes ---

    

    my $last = $self->{market}->last_index();
    my $start = floor($self->{first});
    my $end = ceil($self->{first} + $self->{visible} - 1);
    
    


    $start = 0 if $start < 0;
    $end = $last if $end > $last;

    my $data = $self->{market}->get_slice($start, $end);
    my $atr = $self->{indicators}->slice_array('ATR', $start, $end);



    

    my $step = $plot_w / $self->{visible};

    my $x_of = sub {
        my ($local_i) = @_;
        my $global_i = $start + $local_i;

        return $self->{left}
            + ($step / 2)
            + ($global_i - $self->{first}) * $step;
    };

    my %state = (
        w => $w, h => $h, left => $self->{left}, right => $right, scale_w => $self->{scale_w},
        top => 0, price_h => $price_h, atr_top => $atr_top, atr_h => $self->{atr_h},
        vol_h => $self->{vol_h}, bar_w => $bar_w, auto_y => $self->{auto_y},
        lock_y => $self->{lock_y_on_zoom},
        price_min => $self->{price_min}, price_max => $self->{price_max}, tf => $self->{tf},
        atr_min => $self->{atr_min},
        atr_max => $self->{atr_max},
        start_index => $start,
        end_index   => $end,
        mouse_index => $self->{mouse_index},
        last_candle => $self->{market}->last_candle(),
    );

    $self->draw_time_axis($start, $end, $x_of, $right, $h);
    $self->{price_panel}->draw($c, $data, $x_of, \%state);
    $self->{price_min} = $state{price_min};
    $self->{price_max} = $state{price_max};

    # Limpia el área del ATR para ocultar cualquier vela/volumen que se haya pasado.
    $c->createRectangle(
        $self->{left}, $atr_top,
        $right, $h - $self->{bottom_h},
        -fill => '#131722',
        -outline => '#131722'
    );

$c->createLine($self->{left}, $atr_top, $right, $atr_top, -fill => '#2a2e39', -width => 1);

$self->{atr_panel}->draw($c, $atr, $x_of, \%state);


    $self->{atr_min} = $state{atr_min};
    $self->{atr_max} = $state{atr_max};

    # Contexto de render usado para redibujar solo el crosshair al mover el mouse.
    # Así se evita repintar miles de velas solo por mover el cursor.
    $self->{_last_render_ctx} = {
        start => $start, end => $end, x_of => $x_of, right => $right, h => $h, state => { %state },
    };

    $self->draw_crosshair($start, $end, $x_of, $right, $h, \%state) if defined $self->{mouse_x};
}

sub draw_time_axis {
    my ($self, $start, $end, $x_of, $right, $h) = @_;
    my $c = $self->{canvas};
    my $data = $self->{market}->get_slice($start, $end);
    return if !@$data;

    # Optimización: las etiquetas de tiempo son costosas en Tk. Se dibujan
    # pocos pivots importantes y una cantidad limitada de horas, aunque haya
    # miles de velas visibles.
    my @day_positions;
    my $last_day_x = -9999;
    my $min_day_gap = 48;
    my %seen_day;

    # Pivots de cambio de día. Se revisa toda la ventana, pero solo se dibuja
    # cuando hay suficiente separación visual.
    for my $i (0 .. $#$data) {
        my $time = $data->[$i]{time};
        my ($date) = $time =~ /(\d{4}-\d{2}-\d{2})/;
        next if !defined $date;
        my $prev = $i > 0 ? $data->[$i-1]{time} : '';
        my ($prev_date) = $prev =~ /(\d{4}-\d{2}-\d{2})/;
        my $new_day = defined($prev_date) && $date ne $prev_date;
        next if !$new_day;

        my $x = $x_of->($i);
        next if $x < $self->{left} || $x > $right;
        push @day_positions, $x;
        $c->createLine($x, 0, $x, $h - $self->{bottom_h}, -fill => '#363a45', -tags => 'grid');
        next if $x - $last_day_x < $min_day_gap;
        $last_day_x = $x;
        my $x_label = $x;
        $x_label = $self->{left} + 28 if $x_label < $self->{left} + 28;
        $x_label = $right - 28       if $x_label > $right - 28;
        $c->createText($x_label, $h - 14,
            -text => _day_label($date), -fill => '#d1d4dc',
            -font => ['Arial', 9, 'bold'], -tags => 'time');
    }

    # Horas con salto adaptativo: máximo aprox. 12 etiquetas.
    my $visible = scalar(@$data);
    my $stride = int($visible / 12);
    $stride = 1 if $stride < 1;
    my $last_label_x = -9999;

    for (my $i = 0; $i <= $#$data; $i += $stride) {
        my $time = $data->[$i]{time};
        my ($date, $hh, $mm) = $time =~ /(\d{4}-\d{2}-\d{2})T(\d{2}):(\d{2})/;
        next if !defined $date;
        my $x = $x_of->($i);
        next if $x < $self->{left} || $x > $right;

        my $near_day = 0;
        for my $day_x (@day_positions) {
            if (abs($x - $day_x) < 55) { $near_day = 1; last; }
        }
        next if $near_day;
        next if $x - $last_label_x < 55;
        $last_label_x = $x;

        $c->createLine($x, 0, $x, $h - $self->{bottom_h}, -fill => '#2a2e39', -tags => 'grid');
        $c->createText($x, $h - 14,
            -text => "$hh:$mm", -fill => '#787b86',
            -font => ['Arial', 9, 'normal'], -tags => 'time');
    }
}

sub _day_label {
    my ($date) = @_;
    my ($y, $m, $d) = split /-/, $date;
    return "$d/$m";
}

sub draw_crosshair {
    my ($self, $start, $end, $x_of, $right, $h, $state) = @_;

    my $c = $self->{canvas};

    return if !defined $self->{mouse_x};
    return if !defined $self->{mouse_y};

    my $x = $self->{mouse_x};
    my $y = $self->{mouse_y};

    return if $x < $self->{left};
    return if $x > $right;

    my $idx = $self->x_to_index($x);
    $idx = $start if $idx < $start;
    $idx = $end   if $idx > $end;

    my $local_i = $idx - $start;
    my $candle = $self->{market}->get_candle($idx);

    # Snap horizontal: la línea vertical se pega al centro de la vela.
    if ($candle) {
        $x = $x_of->($local_i);
    }
# Snap vertical a O/H/L/C solo si el mouse está cerca de esos precios.
if ($candle && $y < $state->{atr_top}) {

    my @levels = (
        $candle->{open},
        $candle->{high},
        $candle->{low},
        $candle->{close},
    );

    my $best_y;
    my $best_dist = 999999;

    for my $price (@levels) {
        my $level_y = $self->{price_panel}->{scale}->price_to_y(
            $price,
            $self->{price_min},
            $self->{price_max},
            0,
            $state->{price_h}
        );

        my $dist = abs($y - $level_y);

        if ($dist < $best_dist) {
            $best_dist = $dist;
            $best_y = $level_y;
        }
    }

    # Sensibilidad del snap: 8 px.
    # Sube a 12 si quieres que se pegue más fácil.
    if ($best_dist <= 8) {
        $y = $best_y;
    }
}



    # Línea vertical y horizontal del crosshair
    $c->createLine($x, 0, $x, $h - $self->{bottom_h},
        -fill => '#9598a1', -dash => [4,4], -tags => 'crosshair');

    $c->createLine($self->{left}, $y, $right, $y,
        -fill => '#9598a1', -dash => [4,4], -tags => 'crosshair');




    my $label;

    if ($y < $state->{atr_top}) {
        my $price = $self->{price_panel}->{scale}->y_to_price(
    $y,
    $self->{price_min},
    $self->{price_max},
    0,
    $state->{price_h}
);

$price = _round_to_tick($price, 0.25);
$label = sprintf("%.2f", $price);
    } else {
        $label = sprintf("%.2f", $self->{atr_panel}->{scale}->y_to_price(
            $y,
            $self->{atr_min},
            $self->{atr_max},
            $state->{atr_top},
            $state->{atr_h}
        ));
    }

    $c->createRectangle($right + 2, $y - 10, $right + $self->{scale_w} - 5, $y + 10,
        -fill => '#c62828', -outline => '#c62828', -tags => 'crosshair');

    $c->createText($right + 8, $y,
        -anchor => 'w',
        -text => $label,
        -fill => 'white', -tags => 'crosshair');

    

    if ($candle && $y < $h - $self->{bottom_h}) {
        my ($date, $hhmm) = $candle->{time} =~ /(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2})/;

        my $label_x = $x;

        # Mantener la etiqueta negra dentro del área visible.
        my $label_half_w = 55;
        my $min_x = $self->{left} + $label_half_w;
        my $max_x = $right - $label_half_w;

        $label_x = $min_x if $label_x < $min_x;
        $label_x = $max_x if $label_x > $max_x;

        $c->createRectangle($label_x - $label_half_w, $h - 34,
                            $label_x + $label_half_w, $h - 12,
            -fill => '#363a45', -outline => '#363a45', -tags => 'crosshair');

        $c->createText($label_x, $h - 23,
            -text => "$date  $hhmm",
            -fill => '#d1d4dc',
            -font => ['Arial', 9], -tags => 'crosshair');
    }


    # Mostrar OHLC de la vela actual del crosshair
if ($candle) {
    my $ohlc = sprintf(
        "O %.2f   H %.2f   L %.2f   C %.2f",
        $candle->{open},
        $candle->{high},
        $candle->{low},
        $candle->{close}
    );

    my $color = ($candle->{close} >= $candle->{open}) ? '#089981' : '#f23645';

    $c->createText(
        $self->{left} + 8,
        16,
        -anchor => 'w',
        -text => $ohlc,
        -fill => $color,
        -font => ['Arial', 10, 'bold'],
        -tags => 'crosshair'
    );
}
}

sub mouse_move {
    my ($self, $x, $y, $state) = @_;

    $self->{mouse_x} = $x;
    $self->{mouse_y} = $y;
    $self->{ctrl_down} = ($state & 0x0004) ? 1 : 0;

    my $idx = $self->x_to_index($x);
    my $last = $self->{market}->last_index();

    $idx = 0 if $idx < 0;
    $idx = $last if $idx > $last;

    $self->{mouse_index} = $idx;

    $self->_draw_crosshair_only();
    return;
}

sub x_to_index {
    my ($self, $x) = @_;
    my ($w, $h, $right, $atr_top, $price_h, $plot_w) = $self->layout();

    my $step = $plot_w / $self->{visible};

    my $idx = int(
        $self->{first}
        + (($x - $self->{left} - ($step / 2)) / $step)
        + 0.5
    );

    $idx = 0 if $idx < 0;
    $idx = $self->{market}->last_index if $idx > $self->{market}->last_index;

    return $idx;
}

sub mouse_down {
    my ($self, $x, $y) = @_;
    my ($w, $h, $right, $atr_top) = $self->layout();

    # Drag sobre escala inferior: zoom horizontal
    if ($y >= $h - $self->{bottom_h}) {
        my ($w, $h, $right, $atr_top, $price_h, $plot_w) = $self->layout();

        my $ratio = ($x - $self->{left}) / $plot_w;
        $ratio = 0 if $ratio < 0;
        $ratio = 1 if $ratio > 1;

        $self->{time_scale_drag} = {
            x => $x,
            visible => $self->{visible},
            first => $self->{first},
            ratio => $ratio,
            anchor => $self->{first} + $ratio * $self->{visible},
        };

        return;
    }

    # Click sobre eje Y derecho: activar escalado vertical manual
    if ($x >= $right) {
        my $panel = ($y >= $atr_top) ? 'atr' : 'price';

        $self->{scale_drag} = {
            y => $y,
            panel => $panel,
            price_min => $self->{price_min},
            price_max => $self->{price_max},
            atr_min   => $self->{atr_min},
            atr_max   => $self->{atr_max},
        };

        return;
    }

    if (abs($y - $atr_top) < 6) {
        $self->{resize_atr} = 1;
    } else {
        my $panel = ($y >= $atr_top) ? 'atr' : 'price';

        $self->{drag} = {
            x => $x,
            y => $y,
            first => $self->{first},
            panel => $panel,

            price_min => $self->{price_min},
            price_max => $self->{price_max},

            atr_min => $self->{atr_min},
            atr_max => $self->{atr_max},
        };
    }
}

sub mouse_drag {
    my ($self, $x, $y) = @_;
    my ($w, $h, $right, $atr_top, $price_h, $plot_w) = $self->layout();


    if ($self->{time_scale_drag}) {
        my $dx = $x - $self->{time_scale_drag}{x};

        # Izquierda: alejar / más velas
        # Derecha: acercar / menos velas
        my $factor = exp(-$dx / 250);
        my $new_visible = int($self->{time_scale_drag}{visible} * $factor);

        my $n = $self->{market}->last_index() + 1;
        $new_visible = 2  if $new_visible < 2;
        $new_visible = $n if $new_visible > $n;

        my $ratio  = $self->{time_scale_drag}{ratio};
        my $anchor = $self->{time_scale_drag}{anchor};

        $self->{visible} = $new_visible;
        $self->{first} = $anchor - $ratio * $new_visible;

        $self->limit_first();

        if ($self->{auto_y}) {
            $self->{lock_y_on_zoom} = 0;
            delete $self->{price_min};
            delete $self->{price_max};
            delete $self->{atr_min};
            delete $self->{atr_max};
        }

        $self->request_draw();
        return;
    }

    if ($self->{scale_drag}) {
    my $dy = $y - $self->{scale_drag}{y};

    # Arriba: estirar velas/ATR
    # Abajo: comprimir velas/ATR
    my $factor = 1 + abs($dy) / 180;
    $factor = 1 / $factor if $dy < 0;

    # Si Auto vertical está activo:
    # solo permitimos arrastre horizontal.
    # El eje Y se recalcula automáticamente con las velas visibles.
    if ($self->{auto_y}) {
        $self->{lock_y_on_zoom} = 0;
        $self->request_draw();
        return;
    }

    # Si Auto vertical está apagado:
    # permitimos movimiento vertical manual.
    $self->{lock_y_on_zoom} = 1;

    if ($self->{scale_drag}{panel} eq 'price') {
        my $min = $self->{scale_drag}{price_min};
        my $max = $self->{scale_drag}{price_max};
        my $mid = ($min + $max) / 2;
        my $range = ($max - $min) * $factor;

        $self->{price_min} = $mid - $range / 2;
        $self->{price_max} = $mid + $range / 2;
    } else {
        my $min = $self->{scale_drag}{atr_min};
        my $max = $self->{scale_drag}{atr_max};
        my $mid = ($min + $max) / 2;
        my $range = ($max - $min) * $factor;

        $self->{atr_min} = $mid - $range / 2;
        $self->{atr_max} = $mid + $range / 2;
    }

    $self->request_draw();
    return;
}


    if ($self->{resize_atr}) {
        my $new = $h - $self->{bottom_h} - $y;
        $new = 80 if $new < 80;
        $new = 320 if $new > 320;
        $self->{atr_h} = $new;
    }
    elsif ($self->{drag}) {
        my $dx = $x - $self->{drag}{x};
        my $dy = $y - $self->{drag}{y};

        # Movimiento horizontal: tiempo/eje X
        $self->{first} = $self->{drag}{first} - $dx / $plot_w * $self->{visible};
        $self->limit_first();

            if ($self->{auto_y}) {
        # Auto vertical activo:
        # NO tocar Y manualmente.
        # NO bloquear Y.
        # El draw recalcula la escala con lo visible.
        $self->{lock_y_on_zoom} = 0;

        delete $self->{price_min};
        delete $self->{price_max};
        delete $self->{atr_min};
        delete $self->{atr_max};

        $self->request_draw();
        return;
    }
        $self->{lock_y_on_zoom} = 1;

        if ($self->{drag}{panel} eq 'price') {
            my $range = $self->{drag}{price_max} - $self->{drag}{price_min};
            $range = 1 if $range == 0;

            my $shift = $dy / $price_h * $range;

            $self->{price_min} = $self->{drag}{price_min} + $shift;
            $self->{price_max} = $self->{drag}{price_max} + $shift;
        }
        elsif ($self->{drag}{panel} eq 'atr') {
            my $range = $self->{drag}{atr_max} - $self->{drag}{atr_min};
            $range = 1 if !defined($range) || $range == 0;

            my $shift = $dy / $self->{atr_h} * $range;

            $self->{atr_min} = $self->{drag}{atr_min} + $shift;
            $self->{atr_max} = $self->{drag}{atr_max} + $shift;
        }
    }

    $self->request_draw();
}

sub mouse_up {
    my ($self, $x, $y) = @_;

    delete $self->{drag};
    delete $self->{resize_atr};
    delete $self->{scale_drag};
    delete $self->{time_scale_drag};

    $self->request_draw();
}

sub mouse_wheel {
    my ($self, $delta, $mouse_x, $mouse_y, $state) = @_;

    my $n = $self->{market}->last_index() + 1;
    return if $n <= 0;

    my ($w, $h, $right, $atr_top, $price_h, $plot_w, $bar_w) = $self->layout();

    my $old_visible = $self->{visible};
    my $old_first   = $self->{first};
    my $old_right   = $old_first + $old_visible;

    my $ctrl = defined($state) && ($state & 0x0004);

    my $new_visible;

    if ($delta > 0) {
        $new_visible = int($old_visible * 0.80);   # acercar
        $new_visible = $old_visible - 1 if $new_visible == $old_visible;
    } else {
        $new_visible = int($old_visible * 1.25);   # alejar
        $new_visible = $old_visible + 1 if $new_visible == $old_visible;
    }

    # Límites absolutos de zoom
    $new_visible = 2  if $new_visible < 2;
    $new_visible = $n if $new_visible > $n;

    if ($ctrl && defined($mouse_x) && $mouse_x >= $self->{left} && $mouse_x <= $right) {

        my $current_index = $self->x_to_index($mouse_x);
        $current_index = 0      if $current_index < 0;
        $current_index = $n - 1 if $current_index > $n - 1;

        # Se actualiza el ancla si es primera vez o si cambiaste de vela.
        if (
            !$self->{ctrl_zoom_anchor}
            || $self->{ctrl_zoom_anchor}{mouse_index} != $current_index
        ) {
            $self->{ctrl_zoom_anchor} = {
                index       => $current_index,
                mouse_index => $current_index,
                mouse_x     => $mouse_x,
            };
        }

        my $anchor_index = $self->{ctrl_zoom_anchor}{index};
        my $anchor_x     = $self->{ctrl_zoom_anchor}{mouse_x};

        my $new_step = $plot_w / $new_visible;

        # Fórmula compatible con x_of:
        # x = left + step/2 + (index - first) * step
        # Despejando first:
        $self->{first} = $anchor_index
            - (($anchor_x - $self->{left} - ($new_step / 2)) / $new_step);

    } else {

        # Si ya no hay Ctrl, se libera el congelado.
        delete $self->{ctrl_zoom_anchor};

        # Scroll normal mantiene fijo el borde derecho.
        $self->{first} = $old_right - $new_visible;
    }

    $self->{visible} = $new_visible;

    # IMPORTANTE:
    # En Ctrl + scroll NO llamamos limit_first porque mueve la vela ancla.
    # En scroll normal sí.
    if (!$ctrl) {
        $self->limit_first();
    }

    eval { $self->{canvas}->yviewMoveto(0); };

    if ($self->{auto_y}) {
        $self->{lock_y_on_zoom} = 0;
        delete $self->{price_min};
        delete $self->{price_max};
        delete $self->{atr_min};
        delete $self->{atr_max};
    } else {
        $self->{lock_y_on_zoom} = 1;
    }

    $self->request_draw();
}


sub limit_first {
    my ($self) = @_;

    my $n = $self->{market}->last_index() + 1;
    return if $n <= 0;

    # Extremo izquierdo:
    # permite espacio blanco a la izquierda y deja las 2 primeras velas
    # pegadas al lado derecho, junto a la escala.
    my $min_first = 2 - $self->{visible};

    # Extremo derecho:
    # permite que las 2 últimas velas queden al lado izquierdo
    # y luego haya espacio blanco hacia la derecha.
    my $max_first = $n - 2;

    $max_first = 0 if $max_first < 0;

    $self->{first} = $min_first if $self->{first} < $min_first;
    $self->{first} = $max_first if $self->{first} > $max_first;
}

sub go_to_start {
    my ($self) = @_;

    # Inicio: las 2 primeras velas quedan junto a la escala derecha.
    $self->{first} = 2 - $self->{visible};
    $self->limit_first();

    if ($self->{auto_y}) {
        delete $self->{price_min};
        delete $self->{price_max};
        delete $self->{atr_min};
        delete $self->{atr_max};
        $self->{lock_y_on_zoom} = 0;
    }

    $self->draw();
}

sub go_to_end {
    my ($self) = @_;

    my $n = $self->{market}->last_index() + 1;

    # Queremos que en el borde izquierdo queden solo 2 velas visibles
    # y luego espacio blanco hasta la última vela en el lado derecho.
    $self->{first} = $n - 2;

    if ($self->{auto_y}) {
        delete $self->{price_min};
        delete $self->{price_max};
        delete $self->{atr_min};
        delete $self->{atr_max};
        $self->{lock_y_on_zoom} = 0;
    }

    $self->draw();
}

sub _round_to_tick {
    my ($value, $tick) = @_;
    $tick = 0.25 if !defined $tick || $tick <= 0;
    return int($value / $tick + ($value >= 0 ? 0.5 : -0.5)) * $tick;
}

1;
